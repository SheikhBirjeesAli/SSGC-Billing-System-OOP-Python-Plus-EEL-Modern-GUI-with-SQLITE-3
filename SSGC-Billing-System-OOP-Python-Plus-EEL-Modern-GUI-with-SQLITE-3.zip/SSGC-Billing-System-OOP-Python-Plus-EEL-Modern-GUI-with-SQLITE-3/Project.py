import eel
import sqlite3
from sqlite3 import Error
import time
import random, datetime
from fpdf import FPDF

#Initialize Program to launch

class Employee:
    def __init__(self):
        print("Emp class !")
        eel.login_to_emp()

    @eel.expose
    def back_btn(self):
        eel.goto("home.html")

    @eel.expose
    def generate_btn(self):
        eel.goto("Bill.html")

    @eel.expose
    def back_btn_generate(self):
        eel.goto("EMP.html")

    @eel.expose
    def open_requests(self):
        eel.goto("requests.html")

    @eel.expose
    def logout(self):
        eel.goto("home.html")

    @eel.expose
    def approve(self, con):
        if con != "":
            try:
                db_conn = sqlite3.connect('db/database.db')
                db_cur = db_conn.cursor()
                state = (db_cur.execute('SELECT status from User WHERE consumer_id="%s"' % (con))).fetchone()
                if state != None:

                    i = []
                    for j in state:
                        i.append(j)
                    if i[0] == 0:
                        try:
                            db_cur.execute('UPDATE User SET status = "%s" WHERE consumer_id="%s"' % (1 ,con))
                            db_conn.commit()
                            db_cur.execute('SELECT * from User WHERE consumer_id="%s"' % (con))
                            db_conn.close()
                            eel.invalid("Appoved")
                        except Error as e:
                            print(e)
                    else:
                        eel.invalid("Already Approved !")
                else:
                    eel.invalid("Invalid ID")

            except Error as e:
                eel.invalid("Invalid ID")


    @eel.expose
    def login(typee, id, pas):
        if id != "" and pas != "":
            try:
                db_conn = sqlite3.connect('db/database.db')
                db_cur = db_conn.cursor()
                #db_cusor = db_conn.execute('SELECT * from Employee WHERE ID="%s" AND Password="%s"' % (id, pas))
                db_cur.execute('SELECT * from Employee WHERE ID="%s" AND Password="%s"' % (id, pas))

                if db_cur.fetchone() is not None:
                    eel.goto("EMP.html")
                else:
                    eel.set_popup("Invalid Credentials !")
                    time.sleep(3)
                db_conn.close()

            except Error as e:
                print("Sorry, Database not found !")

        else:
            print("Please fill all Required Fields !")

    @eel.expose
    def generate_bill(con_id, cur_read, read_date, issue_date, gcv, std_tax):
        if con_id != "" and cur_read != "" and read_date != "" and issue_date != "" and gcv != "" and std_tax != "":
            db_conn = sqlite3.connect('db/database.db')
            db_cur = db_conn.cursor()

            # Check if user approved or not
            status = (db_cur.execute('SELECT status from User WHERE consumer_id="%s"' % (con_id))).fetchone()

            i = []
            if status != None:
                for j in status:
                    i.append(j)

                if i[0] != 0 and i[0] != None:
                    try:
                        fetched = []
                        data = (db_cur.execute('SELECT name, address, con_type, meter_number, cnic from User WHERE consumer_id="%s"' % (con_id))).fetchone()
                        for entity in data:
                            fetched.append(entity)

                        dd = issue_date.split("-")
                        idate = datetime.date(int(dd[0]),int(dd[1]),int(dd[2]))
                        month = idate.strftime("%b")
                        prev_month = (idate + datetime.timedelta(days=-30)).strftime("%b")

                        try:
                            prev_bill = []
                            previous_data = (db_cur.execute('SELECT * from "%s" WHERE con_id="%s"' % (prev_month ,int(con_id)))).fetchone()
                            if previous_data != None:
                                print("Found Previous Bill in table", prev_month)
                                for i in previous_data:
                                    prev_bill.append(i)
                            else:
                                prev_bill = [0, 0, "", 0, 0, 0]
                                print("Else: bill not found!")

                            # Check bill was paid or not
                            pay_state = prev_bill[5]

                            # Currency Formatter
                            def currency(amount):
                                return "{:,.0f}".format(amount)

                            # Initialize PDF file
                            bill = FPDF()
                            bill.set_margins(0, 0, 0)
                            bill.add_page()
                            bill.image('layout.png', 0, 0, 210, 300)

                            # Variables
                            name = fetched[0]
                            address = fetched[1]
                            address_first = address[0:(len(address) + 14) // 2]
                            address_second = address[(len(address) + 14) // 2 if len(address) % 2 == 0 else ((len(address) // 2) + 1):]
                            cust_no = con_id
                            bill_id = str(random.randint(111111111111, 999999999999))
                            filename = str(con_id+"-"+str(month))
                            cnic = fetched[4]
                            usage_type = fetched[2]
                            date = idate
                            current = int(cur_read)
                            previous = int(prev_bill[1])
                            measured = current - previous
                            prev_balance = 0

                            if pay_state == 0:
                                prev_balance = float(prev_bill[5])


                            gcv = float(gcv)
                            mmbtu = (((measured / 100) * gcv) / 281.7358)

                            d1 = read_date.split("-")
                            cur_reading = datetime.date(int(d1[0]), int(d1[1]), int(d1[2]))

                            if prev_bill[2] != "":
                                d2 = (prev_bill[2]).split("-")
                                pre_reading = datetime.date(int(d2[0]), int(d2[1]), int(d2[2]))
                                days = cur_reading - pre_reading
                            else:
                                pre_reading = "-"
                                days = "-"

                            #days = cur_reading - pre_reading
                            meter_rent = 20
                            standard_st = int(std_tax)
                            late_surcharge = 10
                            due_date = date + datetime.timedelta(days=14)
                            account_date = date + datetime.timedelta(days=-1)
                            amount = 0

                            # Calculate Amount Acc to Slabs:
                            bill.set_font('Arial', "", 7)

                            ############################### Less than 50 ########################
                            if (measured < 50):

                                # Calculating
                                amount = 173

                                # Printing on PDF
                                bill.text(11, 184.3, "Minimum Charges")
                                bill.text(36.5, 184.3, str(measured))
                                bill.text(54, 184.3, str("{:.3f}".format(mmbtu)))
                                bill.text(74, 184.3, "---")
                                bill.text(92.5, 184.3, str("{:,.0f}".format(amount)))


                            ############################### Upto 50 ########################
                            elif (measured <= 100):
                                # Calculating
                                mmbtu_slab1 = (((50 / 100) * gcv) / 281.7385)
                                amount = (mmbtu_slab1 * 121)
                                measured -= 50

                                # Printing on PDF
                                bill.text(11, 184.3, "Upto 50")
                                bill.text(36.5, 184.3, "50")
                                bill.text(54, 184.3, str("{:.3f}".format(mmbtu_slab1)))
                                bill.text(74, 184.3, "121")
                                bill.text(92.5, 184.3, str("{:,.0f}".format(amount)))

                                # Check if value remains to calculate
                                if (measured == 0):
                                    pass

                                # If Value Remains
                                else:
                                    # Calculation
                                    mmbtu_slab2 = (((measured / 100) * gcv) / 281.7385)
                                    amount += (mmbtu_slab2 * 300)

                                    # Printing on PDF
                                    bill.text(11, 188, "Upto 100")
                                    bill.text(37, 188, str(measured))
                                    bill.text(54, 188, str("{:.3f}".format(mmbtu_slab2)))
                                    bill.text(74, 188, "300")
                                    bill.text(94, 188, str("{:,.0f}".format(mmbtu_slab2 * 300)))

                            ############################### Upto 100 ########################

                            elif (measured <= 200):
                                # Calculation
                                mmbtu_slab1 = (((100 / 100) * gcv) / 281.7385)
                                amount = (mmbtu_slab1 * 300)
                                measured -= 100

                                # Printing on PDF
                                bill.text(11, 184.3, "Upto 100")
                                bill.text(36.5, 184.3, "100")
                                bill.text(54, 184.3, str("{:.3f}".format(mmbtu_slab1)))
                                bill.text(74, 184.3, "300")
                                bill.text(92.5, 184.3, str("{:,.0f}".format(amount)))

                                # Check if value remains to calculate
                                if (measured == 0):
                                    # No value remains
                                    pass

                                # If Value Remains
                                else:
                                    # Calculation
                                    mmbtu_slab2 = (((measured / 100) * gcv) / 281.7385)
                                    amount += (mmbtu_slab2 * 553)
                                    # Printing on PDF
                                    bill.text(11, 188, "Upto 200")
                                    bill.text(37, 188, str(measured))
                                    bill.text(54, 188, str("{:.3f}".format(mmbtu_slab2)))
                                    bill.text(74, 188, "553")
                                    bill.text(94, 188, str("{:,.0f}".format(mmbtu_slab2 * 553)))


                            ############################### Upto 200 ########################

                            elif (measured <= 300):
                                # Calculation
                                mmbtu_slab1 = (((200 / 100) * gcv) / 281.7385)
                                amount = (mmbtu_slab1 * 553)
                                measured -= 200

                                # Printing on PDF
                                bill.text(11, 184.3, "Upto 200")
                                bill.text(36.5, 184.3, "200")
                                bill.text(54, 184.3, str("{:.3f}".format(mmbtu_slab1)))
                                bill.text(74, 184.3, "553")
                                bill.text(92.5, 184.3, str("{:,.0f}".format(amount)))

                                # Check if value remains to calculate
                                if (measured == 0):
                                    # No value remains
                                    pass

                                # If Value Remains
                                else:
                                    # Calculation
                                    mmbtu_slab2 = (((measured / 100) * gcv) / 281.7385)
                                    amount += (mmbtu_slab2 * 738)
                                    # Printing on PDF
                                    bill.text(11, 188, "Upto 300")
                                    bill.text(37, 188, str(measured))
                                    bill.text(54, 188, str("{:.3f}".format(mmbtu_slab2)))
                                    bill.text(74, 188, "738")
                                    bill.text(94, 188, str("{:,.0f}".format(mmbtu_slab2 * 553)))


                            ############################### Upto 300 ########################

                            elif (measured <= 400):
                                # Calculation
                                mmbtu_slab1 = (((300 / 100) * gcv) / 281.7385)
                                amount = (mmbtu_slab1 * 738)
                                measured -= 300

                                # Printing on PDF
                                bill.text(11, 184.3, "Upto 300")
                                bill.text(36.5, 184.3, "200")
                                bill.text(54, 184.3, str("{:.3f}".format(mmbtu_slab1)))
                                bill.text(74, 184.3, "738")
                                bill.text(92.5, 184.3, str("{:,.0f}".format(amount)))

                                # Check if value remains to calculate
                                if (measured == 0):
                                    # No value remains
                                    pass

                                # If Value Remains
                                else:
                                    # Calculation
                                    mmbtu_slab2 = (((measured / 100) * gcv) / 281.7385)
                                    amount += (mmbtu_slab2 * 1107)
                                    # Printing on PDF
                                    bill.text(11, 188, "Upto 400")
                                    bill.text(37, 188, str(measured))
                                    bill.text(54, 188, str("{:.3f}".format(mmbtu_slab2)))
                                    bill.text(74, 188, "1107")
                                    bill.text(94, 188, str("{:,.0f}".format(mmbtu_slab2 * 553)))


                            ############################### Upto 400 ########################
                            elif (measured > 400):
                                # Calculation
                                mmbtu_slab1 = (((measured / 100) * gcv) / 281.7385)
                                amount = (mmbtu_slab1 * 1460)

                                # Printing on PDF
                                bill.text(11, 184.3, "Upto 400")
                                bill.text(36.5, 184.3, str(measured))
                                bill.text(54, 184.3, str("{:.3f}".format(mmbtu)))
                                bill.text(74, 184.3, "1460")
                                bill.text(92.5, 184.3, str("{:,.0f}".format(amount)))

                            total_amount = standard_st + meter_rent + amount
                            late_surcharge_amount = ((late_surcharge * total_amount) / 100)
                            after_due_amount = (late_surcharge_amount + total_amount + prev_balance)

                            # Name and Address
                            bill.set_font('Arial', 'B', 8)
                            bill.text(25, 22, name)
                            bill.set_font('Arial', "", 8)
                            bill.text(25, 26, address_first + "-")
                            bill.text(25, 29, address_second)
                            # Account Information
                            # Bolded
                            bill.set_font('Arial', "B", 7)
                            bill.text(40, 41.5, cust_no)
                            bill.text(40, 45, str(date.strftime("%b, %Y")))
                            bill.text(40, 48.5, usage_type)
                            # Normal
                            bill.set_font('Arial', "", 7)
                            bill.text(80, 41.5, bill_id)
                            bill.text(37, 52, cnic)
                            bill.text(48, 55, "-----")
                            bill.text(123, 55.5, str(date.strftime("%d-%b-%Y")))
                            # Account Summary
                            bill.set_font('Arial', "B", 10)
                            # Account Summary Date
                            bill.text(118, 62, str(account_date.strftime("%d-%b-%Y")))
                            bill.text(24, 75, str(prev_balance))
                            bill.text(52, 75, currency(total_amount))
                            bill.text(84, 75, currency(total_amount + prev_balance))
                            bill.text(116, 75, currency(late_surcharge_amount))
                            bill.text(148, 75, currency(after_due_amount))
                            bill.text(177, 75, str(due_date.strftime("%d-%b-%Y")))
                            # Bill and Payment History
                            # Paid Bill Months
                            bill.set_font('Arial', "", 8)
                            bill.text(107, 90, "-----")
                            bill.text(107, 94.5, "-----")
                            bill.text(107, 99.4, "-----")
                            bill.text(107, 104, "-----")
                            bill.text(107, 109, "-----")
                            bill.text(107, 113.8, "-----")
                            # Bill Amounts to PAY
                            bill.text(137, 90, "-----")
                            bill.text(137, 94.5, "-----")
                            bill.text(137, 99.4, "-----")
                            bill.text(137, 104, "-----")
                            bill.text(137, 109, "-----")
                            bill.text(137, 113.8, "-----")
                            # Payment Dates
                            bill.text(157, 90, "-----")
                            bill.text(157, 94.5, "-----")
                            bill.text(157, 99.4, "-----")
                            bill.text(157, 104, "-----")
                            bill.text(157, 109, "-----")
                            bill.text(157, 113.8, "-----")
                            # Paid Bill Amounts
                            bill.text(185, 90, "-----")
                            bill.text(185, 94.5, "-----")
                            bill.text(185, 99.4, "-----")
                            bill.text(185, 104, "-----")
                            bill.text(185, 109, "-----")
                            bill.text(185, 113.8, "-----")
                            # Meter Information
                            bill.set_font('Arial', "", 7)
                            bill.text(14, 144, fetched[3])
                            bill.text(30, 144, str(cur_reading.strftime("%d-%b-%Y")))
                            bill.text(45, 144, str(current))
                            if pre_reading != "-":
                                bill.text(57, 144, str(pre_reading.strftime("%d-%b-%Y")))
                            else:
                                bill.text(57, 144, pre_reading)
                            if previous != 0:
                                bill.text(72, 144, str(previous))
                            else:
                                bill.text(72, 144, "-")
                            bill.text(91, 144, str(current - previous))
                            bill.text(18, 154, "---")
                            bill.text(42, 154, str(gcv))
                            bill.text(63, 154, "{:.6f}".format(mmbtu))
                            bill.text(94, 154, "1")
                            bill.text(18, 161, "---")
                            bill.text(44, 161, "---")
                            bill.text(67, 161, "---")
                            bill.text(94, 161, "---")
                            # Bill Calculation of Current Gas charges
                            bill.text(46, 172.6, "---")
                            bill.text(62.5, 172.6, "---")
                            bill.text(79, 172.6, "---")
                            bill.text(94.6, 172.6, "---")
                            bill.text(44.6, 176, str("{:.0f}".format(current - previous)))
                            bill.text(60.5, 176, str("{:.3f}".format(mmbtu)))
                            if days != "-":
                                bill.text(79, 176, str(days.days))
                            else:
                                bill.text(79, 176, "---")
                            # Meter information Amount
                            bill.text(92, 176, str("{:,.0f}".format(amount)))
                            # Details of Charges
                            bill.text(191, 122.7, str("{:,.0f}".format(amount)))
                            bill.text(195, 126, str("{:,.0f}".format(meter_rent)))
                            bill.text(194, 136.5, str("{:,.0f}".format(standard_st)))
                            bill.text(192, 182.6, str("{:,.0f}".format(standard_st + meter_rent + amount)))
                            # Footer of PDf
                            bill.set_font('Arial', "B", 10)
                            bill.text(30, 282, cust_no)
                            bill.text(80, 282, "Rs. " + currency(total_amount))
                            bill.text(117, 282, str(due_date.strftime("%d-%b-%Y")))
                            bill.text(164, 282, currency(after_due_amount))
                            bill.set_font('Arial', 'B', 8)
                            bill.text(130, 248, name)
                            bill.set_font('Arial', "", 8)
                            bill.text(130, 251, address_first + "-")
                            bill.text(130, 254, address_second)
                            bill.set_font('Arial', 'B', 8)
                            bill.text(105, 259, cust_no)
                            bill.text(125, 270, "Bill ID: " + bill_id)

                            try:
                                db_conn.execute("INSERT INTO "+month+" (con_id, current_reading, read_date, bill_amount, bill_id, pay_state) VALUES (?,?,?,?,?,?)", (con_id, current, read_date, (after_due_amount), bill_id, 0))
                                db_conn.commit()
                                bill.output("templates/Login/Bills/" + filename + ".pdf", 'F')
                                eel.invalid("Bill Generated Succesfully !")
                            except Error as e:
                                print("Bill was already generated !")
                                db_conn.close()
                        except Error as e:
                            print(e)
                            db_conn.close()
                    except Error as e:
                        print(e)
                        eel.invalid("This User does'nt Exist !")
                        db_conn.close()
                else:
                    eel.invalid("This User is not Approved Yet !")

            else:
                eel.invalid("This User is not Exist, Register it First !")
                db_conn.close()
        else:
            eel.invalid("Invalid Details !")

class User:
    def __init__(self):
        eel.goto("New_Con.html")

    @eel.expose
    def back_btn_new(self):
        eel.goto("home.html")

    @eel.expose
    def find(self, bill_con, bill_month):
        if bill_con != "" and bill_month != "":
            try:
                path = "templates/Login/Bills/"+bill_con+"-"+bill_month+".pdf"
                path_js = "Bills/"+bill_con+"-"+bill_month+".pdf"
                #print(path)
                file = open(path, "r")
                eel.open(path_js)
            except:
                eel.invalid("Not Found !")
        else:
            eel.invalid("Incorrect Details.")

    @eel.expose
    def submit_request(name, address, city, con_type, cnic, phone):
        if name != "" and address != "" and city != "" and con_type != "" and cnic != "" and phone != "":
            try:
                meter_number = "M"+str(random.randint(1111111, 9999999))
                consumer_id = random.randint(1111111111, 9999999999)

                db_conn = sqlite3.connect('db/database.db')
                db_cur = db_conn.cursor()
                db_cur.execute("INSERT INTO User ( cnic, name, address, city, con_type, phone, meter_number, consumer_id, status) VALUES (?,?,?,?,?,?,?,?,?)", (cnic, name, address, city, con_type, phone, meter_number, consumer_id, 0))
                db_conn.commit()
                db_conn.close()
                eel.invalid("Request Submitted Successfully! Wait for Approved from SSGC")

            except Error as e:
                print("Sorry, Database not found !", e)

        else:
            eel.invalid("Invalid Details !")


class Initialize:

    eel.init('templates/Login')

    @eel.expose
    def func(x):
        print(x)

    @eel.expose
    def btn_click(arg):
        if arg == "login":
            Employee()
        elif arg == "new_con":
            User()
        elif arg == "view_bill":
            eel.goto("view.html")

    eel.start('home.html', mode='chrome', size=(800, 750), host='localhost', port=8274)


#if __name__ == __main__:
Initialize()
