eel.func("Home Page Opened !")

function login(){
    eel.func("Login as employee")
    eel.btn_click("login")
}

function new_con(){
    eel.btn_click("new_con")
}

function open_requests(){
    eel.open_requests("self")
}

function view_bill(){
    eel.btn_click("view_bill")
}

eel.expose(login_to_emp)
function login_to_emp(){
    window.location.href = "login.html";
}

function generate_btn(){
    eel.generate_btn("self")
}


eel.expose(goto)
function goto(arg){
    window.location.href = arg;
}

eel.expose(invalid)
function invalid(x){
    window.alert(x);
}