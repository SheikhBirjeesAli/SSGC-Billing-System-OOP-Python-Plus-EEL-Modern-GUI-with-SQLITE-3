eel.func("Employee Login Opened !");

eel.expose(goto)
function goto(dest){
    window.location.href = dest;
}

function back_btn(){
    eel.back_btn("back");
}

function back_btn_generate(){
    eel.back_btn_generate("self");
}

function back_btn_new(){
    eel.back_btn_new("self");
}

eel.expose(invalid)
function invalid(x){
    window.alert(x);
}


eel.expose(open)
function open(x){
    window.location.href = x;
}

function clicked() {
    var emp_id = document.getElementById("emp_id").value
    var pass = document.getElementById("pass_txt").value
    eel.login("EMP", emp_id, pass);
}

function find() {
    var bill_con = document.getElementById("bill_con").value
    var bill_month = document.getElementById("bill_month").value
    eel.find("self", bill_con, bill_month);
}

eel.expose(set_popup)
function set_popup(x){
    document.getElementById("pop_up").textContent=x;
}

function generate_bill(){
    var con_id = document.getElementById("con_id").value
    var cur_read = document.getElementById("cur_read").value
    var read_date = document.getElementById("read_date").value
    var issue_date = document.getElementById("issue_date").value
    var gcv = document.getElementById("gcv").value
    var std_tax = document.getElementById("std_tax").value

    eel.generate_bill(con_id, cur_read, read_date,issue_date, gcv, std_tax)
}

function submit_request(){
    var name = document.getElementById("name").value
    var address = document.getElementById("address").value
    var city = document.getElementById("city").value
    var con_type = document.getElementById("con_type").value
    var cnic = document.getElementById("cnic").value
    var phone = document.getElementById("phone").value

    eel.submit_request(name, address, city, con_type, cnic, phone)
}

function approve(){
    var con_id_app = document.getElementById("con_id_app").value
    eel.approve("self", con_id_app)
}

